# ♟ Checkers — Шашки

A fully-featured Checkers game with AI opponent, 4 skins & 4 languages — pure HTML/CSS/JS, zero dependencies, single file.

🎮 **[Play Live →](https://YOUR-USERNAME.github.io/checkers)**

---

## How to Play

| Step | Action |
|------|--------|
| 1 | Click **your piece** (blue 🔵, bottom of board) — it highlights |
| 2 | **Green dots** appear → valid squares to move |
| 3 | Click a **green dot** to move there |
| 4 | **Bright green dot** = capture move (jump over enemy) |
| 5 | **Flashing orange** piece = mandatory capture — you must use it |
| 6 | Reach the far end → become a **King ★** (moves in all 4 directions) |
| 7 | Win by capturing all enemy pieces or blocking them |

> ⚠️ **Captures are mandatory** in checkers — if you can take a piece, you must!

---

## Features

- 🤖 **3 AI Difficulty Levels**
  - **Easy** — random moves, prefers captures
  - **Medium** — Minimax depth 3 (thinks 3 moves ahead)
  - **Hard** — Minimax + Alpha-Beta pruning depth 5 (strong opponent)
- 🎨 **4 Piece Skins**
  - ⚡ **Cyber** — neon 3D pieces on dark board
  - 🌈 **Neon** — glowing cyan/magenta on black
  - 🪵 **Retro** — gold & silver on wooden board
  - 😈 **Emoji** — 🔵🔴 with 👑🎯 for kings
- 🌍 **4 Languages** — Ukrainian 🇺🇦 · English 🇬🇧 · German 🇩🇪 · French 🇫🇷
- 💡 **Visual hints** — green dots for moves, bright dots for captures, orange flash for mandatory pieces
- 🏆 **Score tracking** across games
- ♟ **Full rules** — mandatory captures, multi-jumps, kings, blocking win
- 📱 **Mobile friendly**
- ⚡ **Zero dependencies** — one `index.html` file

---

## AI Details

```
Easy   → depth 1  (random with capture preference)
Medium → depth 3  (Minimax — thinks 3 plies deep)
Hard   → depth 5  (Minimax + Alpha-Beta pruning)
```

Evaluation: piece count, king value ×3.2, center control, board advancement, back-row bonus, edge penalty.

---

## Run Locally

```bash
git clone https://github.com/YOUR-USERNAME/checkers.git
cd checkers
open index.html
```

## Deploy to GitHub Pages

1. Push to GitHub
2. **Settings → Pages → main / root → Save**
3. Live at `https://YOUR-USERNAME.github.io/checkers` 🚀

---

## License

MIT
