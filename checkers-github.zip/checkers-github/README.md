# ♟ Checkers — Шашки

A fully-featured Checkers game with AI opponent, 4 skins, and 4 languages — built in pure HTML/CSS/JS, zero dependencies.

🎮 **[Play Live →](https://YOUR-USERNAME.github.io/checkers)**

![Checkers Preview](preview.png)

---

## How to Play

| Action | How |
|--------|-----|
| Select a piece | Click on your piece (blue / bottom side) |
| Move | Green hints appear — click one to move |
| Capture | Jump over an enemy piece diagonally |
| Multi-jump | After a capture, keep jumping if possible |
| Mandatory capture | If you can capture — you must |
| Become a King (★) | Reach the opposite end of the board |
| King moves | Can move and capture in all 4 diagonal directions |
| Win | Capture all enemy pieces or block them completely |

> You play as **Blue 🔵** (bottom). AI plays as **Red 🔴** (top).

---

## Features

- 🤖 **3 AI Difficulty Levels**
  - **Easy** — random moves with capture preference
  - **Medium** — Minimax algorithm, depth 3
  - **Hard** — Minimax + Alpha-Beta pruning, depth 5
- 🎨 **4 Piece Skins** — Cyber ⚡ · Neon 🌈 · Retro 🪵 · Emoji 😈
- 🌍 **4 Languages** — Ukrainian 🇺🇦 · English 🇬🇧 · German 🇩🇪 · French 🇫🇷
- 🏆 **Score tracking** across multiple games
- ✅ **Full rules** — mandatory captures, multi-jumps, kings
- 💡 **Move hints** — valid moves highlighted in green
- 📱 **Mobile friendly** — works on any screen size
- ⚡ **Zero dependencies** — single `index.html` file

---

## AI Details

The AI uses the **Minimax algorithm** with **Alpha-Beta pruning**:

```
Easy   → depth 1  (random-ish, prefers captures)
Medium → depth 3  (thinks 3 moves ahead)
Hard   → depth 5  (strong opponent, ~1s think time)
```

Evaluation function weighs: piece count, king value (×3), center control, board advancement.

---

## Tech Stack

| | |
|---|---|
| Language | HTML5 + CSS3 + Vanilla JS |
| Fonts | Google Fonts (Orbitron, Share Tech Mono) |
| AI | Minimax + Alpha-Beta pruning |
| Build | None — open `index.html` directly |

---

## Run Locally

```bash
git clone https://github.com/YOUR-USERNAME/checkers.git
cd checkers
open index.html   # or double-click the file
```

---

## Deploy to GitHub Pages

1. Push this repo to GitHub
2. Go to **Settings → Pages**
3. Source: **Deploy from branch** → `main` → `/ (root)`
4. Save — live at `https://YOUR-USERNAME.github.io/checkers` 🚀

---

## Project Structure

```
checkers/
├── index.html      # Entire game — HTML + CSS + JS
├── README.md
├── LICENSE
└── .gitignore
```

---

## License

MIT — free to use, modify and distribute.
